async function hunt() {
  const chain = document.getElementById("chain").value;
  const url = `https://api.dexscreener.com/latest/dex/pairs/${chain}`;
  const res = await fetch(url);
  const data = await res.json();
  const results = document.getElementById("results");
  results.innerHTML = "";

  const minCap = 100000;
  const maxCap = 500000;
  const minLiq = 110000;

  if (data.pairs) {
    data.pairs.forEach(p => {
      const change1h = p.priceChange?.h1 || 0;
      const fdv = p.fdv || 0;
      const liq = p.liquidity?.usd || 0;
      const age = p.pairCreatedAt ?
        Math.floor((Date.now() - p.pairCreatedAt)/3600000) : 999;

      if (change1h >= 5 && fdv >= minCap && fdv <= maxCap && liq >= minLiq && age >= 6) {
        const div = document.createElement("div");
        div.className = "card";
        div.innerHTML = `
          <b>${p.baseToken.symbol}</b> / ${p.quoteToken.symbol}<br>
          💲 قیمت: ${p.priceUsd}<br>
          📈 تغییر 1h: ${change1h}%<br>
          🏦 FDV: $${fdv}<br>
          💧 لیکوئیدیتی: $${liq}<br>
          ⏳ سن: ${age} ساعت<br>
          🔗 <a href="${p.url}" target="_blank">DexScreener</a><br>
          📝 کانترکت: ${p.baseToken.address}
        `;
        results.appendChild(div);
      }
    });
  }
}